package com.example.easymanage;

public interface TAGS {

     String INFO = "[INFO]";
     String ERROR = "[ERROR]";
     String WARN = "[WARN]";




}
